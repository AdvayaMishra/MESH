from typing import Annotated, Literal
from uuid import UUID

from fastapi import APIRouter, Header, HTTPException
from pydantic import Field, SecretStr

from app.api import DB, Who
from app.auth import Principal
from app.core.config import settings
from app.core.db import tenant_context
from app.identity_provider import SupabaseAuth
from app.models import Membership
from app.schemas import Input
from app.services import emit, lock_tenant
from app.sessions import revoke_all

router = APIRouter(prefix="/api/v1")


class PasswordInput(Input):
    password: SecretStr = Field(min_length=12, max_length=128)


class OrganizationStatus(Input):
    status: Literal["active", "suspended"]


@router.put("/auth/password", status_code=204)
def update_password(data: PasswordInput, who: Who, db: DB, authorization: Annotated[str, Header()]):
    # Provider recovery OTP already produced the authenticated session; password remains provider-owned.
    SupabaseAuth().request(
        "user",
        {"password": data.password.get_secret_value()},
        token=authorization.split(" ", 1)[1],
        method="PUT",
    )
    revoke_all(db, who.user_id, keep=who.session_id, reason="password_changed")


@router.patch("/organizations/current/status", response_model=OrganizationStatus)
def organization_status(
    data: OrganizationStatus,
    who: Who,
    db: DB,
    organization: Annotated[UUID, Header(alias="X-Organization-ID")],
):
    org = str(organization)
    tenant_context(db, org, who.user_id)
    membership = db.get(Membership, (org, who.user_id), populate_existing=True)
    if membership is None or not membership.active or membership.role != "owner":
        raise HTTPException(403, "Active owner membership required")
    if settings().require_privileged_mfa and who.aal != "aal2":
        raise HTTPException(403, "MFA assurance level 2 required")
    record = lock_tenant(db, org)
    if record is None:
        raise HTTPException(404, "Organization not found")
    # A revocation can commit while this request waits for the tenant lock.
    # Refresh after acquiring it, then retain tenant-before-member lock order.
    membership = db.get(
        Membership, (org, who.user_id), with_for_update=True, populate_existing=True
    )
    if membership is None or not membership.active or membership.role != "owner":
        raise HTTPException(403, "Active owner membership required")
    record.status = data.status
    emit(db, Principal(who.user_id, org, "owner"), "organization." + data.status, org)
    return data

BEGIN;

CREATE TABLE alembic_version (
    version_num VARCHAR(32) NOT NULL, 
    CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num)
);

-- Running upgrade  -> 0001

CREATE TABLE organizations (
    id VARCHAR(36) NOT NULL, 
    name VARCHAR(200) NOT NULL, 
    status VARCHAR NOT NULL, 
    verification_status VARCHAR NOT NULL, 
    domain VARCHAR(253), 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    UNIQUE (domain)
);

CREATE TABLE audit_logs (
    actor_id VARCHAR(36) NOT NULL, 
    action VARCHAR(100) NOT NULL, 
    target_id VARCHAR(100) NOT NULL, 
    outcome VARCHAR NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id)
);

CREATE INDEX ix_audit_logs_organization_id ON audit_logs (organization_id);

CREATE TABLE deliveries (
    message_id VARCHAR(36) NOT NULL, 
    consumer VARCHAR(100) NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id), 
    UNIQUE (organization_id, message_id, consumer)
);

CREATE INDEX ix_deliveries_organization_id ON deliveries (organization_id);

CREATE TABLE domain_challenges (
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    domain VARCHAR(253) NOT NULL, 
    token_hash VARCHAR(64) NOT NULL, 
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    attempts INTEGER NOT NULL, 
    status VARCHAR NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id)
);

CREATE INDEX ix_domain_challenges_organization_id ON domain_challenges (organization_id);

CREATE TABLE incidents (
    actor_id VARCHAR(100) NOT NULL, 
    fingerprint VARCHAR(64) NOT NULL, 
    event_ids JSON NOT NULL, 
    risk INTEGER NOT NULL, 
    explanation VARCHAR(1000) NOT NULL, 
    status VARCHAR NOT NULL, 
    synthetic BOOLEAN NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id), 
    UNIQUE (organization_id, fingerprint), 
    UNIQUE (organization_id, id)
);

CREATE INDEX ix_incidents_organization_id ON incidents (organization_id);

CREATE TABLE invitations (
    email VARCHAR(254) NOT NULL, 
    role VARCHAR(30) NOT NULL, 
    token_hash VARCHAR(64) NOT NULL, 
    creator_id VARCHAR(36) NOT NULL, 
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    accepted_at TIMESTAMP WITH TIME ZONE, 
    status VARCHAR NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id), 
    UNIQUE (token_hash)
);

CREATE INDEX ix_invitations_organization_id ON invitations (organization_id);

CREATE TABLE memberships (
    organization_id VARCHAR(36) NOT NULL, 
    user_id VARCHAR(36) NOT NULL, 
    email VARCHAR(254) NOT NULL, 
    role VARCHAR(30) NOT NULL, 
    active BOOLEAN NOT NULL, 
    PRIMARY KEY (organization_id, user_id), 
    CHECK (role IN ('owner','hr','senior_developer','junior_developer','security_analyst')), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id), 
    UNIQUE (organization_id, email)
);

CREATE TABLE outbox (
    topic VARCHAR(100) NOT NULL, 
    payload JSON NOT NULL, 
    attempts INTEGER NOT NULL, 
    available_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    status VARCHAR NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id)
);

CREATE INDEX ix_outbox_organization_id ON outbox (organization_id);

CREATE TABLE projects (
    name VARCHAR(200) NOT NULL, 
    description VARCHAR(4000) NOT NULL, 
    proposer_id VARCHAR(36) NOT NULL, 
    status VARCHAR NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    CHECK (status IN ('proposed','reviewed','approved','rejected')), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id), 
    UNIQUE (organization_id, id)
);

CREATE INDEX ix_projects_organization_id ON projects (organization_id);

CREATE TABLE repositories (
    full_name VARCHAR(200) NOT NULL, 
    installation_id INTEGER NOT NULL, 
    enabled BOOLEAN NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id), 
    UNIQUE (organization_id, full_name), 
    UNIQUE (organization_id, id)
);

CREATE INDEX ix_repositories_organization_id ON repositories (organization_id);

CREATE TABLE security_events (
    source_id VARCHAR(150) NOT NULL, 
    occurred_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    actor_id VARCHAR(100) NOT NULL, 
    category VARCHAR(50) NOT NULL, 
    action VARCHAR(80) NOT NULL, 
    result VARCHAR(30) NOT NULL, 
    count INTEGER NOT NULL, 
    synthetic BOOLEAN NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id), 
    UNIQUE (organization_id, id), 
    UNIQUE (organization_id, source_id)
);

CREATE INDEX ix_event_actor_time ON security_events (organization_id, actor_id, occurred_at);

CREATE INDEX ix_security_events_organization_id ON security_events (organization_id);

CREATE TABLE anomalies (
    event_id VARCHAR(36) NOT NULL, 
    rule VARCHAR(80) NOT NULL, 
    weight INTEGER NOT NULL, 
    explanation VARCHAR(500) NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, event_id) REFERENCES security_events (organization_id, id), 
    UNIQUE (organization_id, event_id, rule)
);

CREATE INDEX ix_anomalies_organization_id ON anomalies (organization_id);

CREATE TABLE employees (
    user_id VARCHAR(36) NOT NULL, 
    name VARCHAR(200) NOT NULL, 
    department VARCHAR(100) NOT NULL, 
    status VARCHAR NOT NULL, 
    verification_status VARCHAR NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, user_id) REFERENCES memberships (organization_id, user_id), 
    UNIQUE (organization_id, id), 
    UNIQUE (organization_id, user_id)
);

CREATE INDEX ix_employees_organization_id ON employees (organization_id);

CREATE TABLE findings (
    repository_id VARCHAR(36) NOT NULL, 
    scanner VARCHAR(30) NOT NULL, 
    rule_id VARCHAR(200) NOT NULL, 
    severity VARCHAR(20) NOT NULL, 
    file_path VARCHAR(500) NOT NULL, 
    line INTEGER NOT NULL, 
    status VARCHAR NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, repository_id) REFERENCES repositories (organization_id, id)
);

CREATE INDEX ix_findings_organization_id ON findings (organization_id);

CREATE TABLE response_actions (
    incident_id VARCHAR(36) NOT NULL, 
    action VARCHAR(50) NOT NULL, 
    proposed_by VARCHAR(36) NOT NULL, 
    approved_by VARCHAR(36), 
    status VARCHAR NOT NULL, 
    mode VARCHAR NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, incident_id) REFERENCES incidents (organization_id, id)
);

CREATE INDEX ix_response_actions_organization_id ON response_actions (organization_id);

CREATE TABLE tasks (
    project_id VARCHAR(36) NOT NULL, 
    assignee_id VARCHAR(36) NOT NULL, 
    title VARCHAR(200) NOT NULL, 
    status VARCHAR NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, assignee_id) REFERENCES memberships (organization_id, user_id), 
    FOREIGN KEY(organization_id, project_id) REFERENCES projects (organization_id, id)
);

CREATE INDEX ix_tasks_organization_id ON tasks (organization_id);

CREATE TABLE trust_events (
    user_id VARCHAR(36) NOT NULL, 
    reference VARCHAR(100) NOT NULL, 
    delta INTEGER NOT NULL, 
    reason VARCHAR(500) NOT NULL, 
    reviewed_by VARCHAR(36) NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    CHECK (delta BETWEEN -10 AND 10), 
    FOREIGN KEY(organization_id, user_id) REFERENCES memberships (organization_id, user_id), 
    UNIQUE (organization_id, reference)
);

CREATE INDEX ix_trust_events_organization_id ON trust_events (organization_id);

CREATE TABLE payroll (
    employee_id VARCHAR(36) NOT NULL, 
    period VARCHAR(7) NOT NULL, 
    currency VARCHAR(3) NOT NULL, 
    gross NUMERIC(14, 2) NOT NULL, 
    deductions NUMERIC(14, 2) NOT NULL, 
    net NUMERIC(14, 2) NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    CHECK (gross >= 0 AND deductions >= 0 AND net >= 0 AND net = gross - deductions), 
    FOREIGN KEY(organization_id, employee_id) REFERENCES employees (organization_id, id), 
    UNIQUE (organization_id, employee_id, period)
);

CREATE INDEX ix_payroll_organization_id ON payroll (organization_id);

ALTER TABLE "organizations" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "organizations" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "organizations"
            USING (id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "audit_logs" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "audit_logs" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "audit_logs"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "deliveries" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "deliveries" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "deliveries"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "domain_challenges" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "domain_challenges" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "domain_challenges"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "incidents" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "incidents" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "incidents"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "invitations" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "invitations" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "invitations"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "memberships" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "memberships" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "memberships"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "outbox" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "outbox" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "outbox"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "projects" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "projects" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "projects"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "repositories" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "repositories" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "repositories"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "security_events" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "security_events" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "security_events"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "anomalies" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "anomalies" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "anomalies"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "employees" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "employees" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "employees"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "findings" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "findings" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "findings"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "response_actions" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "response_actions" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "response_actions"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "tasks" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "tasks" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "tasks"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "trust_events" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "trust_events" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "trust_events"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "payroll" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "payroll" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "payroll"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

CREATE FUNCTION mesh_deny_ledger_mutation() RETURNS trigger
      LANGUAGE plpgsql AS $$ BEGIN RAISE EXCEPTION 'append-only ledger'; END; $$;

CREATE TRIGGER append_only BEFORE UPDATE OR DELETE ON audit_logs FOR EACH ROW EXECUTE FUNCTION mesh_deny_ledger_mutation();

CREATE TRIGGER append_only BEFORE UPDATE OR DELETE ON trust_events FOR EACH ROW EXECUTE FUNCTION mesh_deny_ledger_mutation();

INSERT INTO alembic_version (version_num) VALUES ('0001') RETURNING alembic_version.version_num;

-- Running upgrade 0001 -> 0002

CREATE UNIQUE INDEX uq_tasks_org_id ON tasks (organization_id, id);

ALTER TABLE security_events ADD COLUMN session_id VARCHAR(100);

ALTER TABLE security_events ADD COLUMN resource_id VARCHAR(100);

CREATE TABLE ai_usage (
    provider VARCHAR(50) NOT NULL, 
    purpose VARCHAR(30) NOT NULL, 
    input_units INTEGER NOT NULL, 
    output_units INTEGER NOT NULL, 
    estimated_cost NUMERIC(14, 6), 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id)
);

CREATE INDEX ix_ai_usage_organization_id ON ai_usage (organization_id);

CREATE TABLE budgets (
    period VARCHAR(7) NOT NULL, 
    currency VARCHAR(3) NOT NULL, 
    amount NUMERIC(14, 2) NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    CHECK (amount >= 0), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id), 
    UNIQUE (organization_id, period, currency)
);

CREATE INDEX ix_budgets_organization_id ON budgets (organization_id);

CREATE TABLE cloud_assessments (
    provider VARCHAR NOT NULL, 
    findings JSON NOT NULL, 
    partial BOOLEAN NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id)
);

CREATE INDEX ix_cloud_assessments_organization_id ON cloud_assessments (organization_id);

CREATE TABLE cost_records (
    period VARCHAR(7) NOT NULL, 
    department VARCHAR(100) NOT NULL, 
    category VARCHAR(30) NOT NULL, 
    currency VARCHAR(3) NOT NULL, 
    amount NUMERIC(14, 2) NOT NULL, 
    source VARCHAR NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    CHECK (amount >= 0), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id)
);

CREATE INDEX ix_cost_records_organization_id ON cost_records (organization_id);

CREATE TABLE departments (
    name VARCHAR(100) NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id), 
    UNIQUE (organization_id, name)
);

CREATE INDEX ix_departments_organization_id ON departments (organization_id);

CREATE TABLE detection_policies (
    thresholds JSON NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id), 
    UNIQUE (organization_id)
);

CREATE INDEX ix_detection_policies_organization_id ON detection_policies (organization_id);

CREATE TABLE audit_seals (
    audit_id VARCHAR(36) NOT NULL, 
    position INTEGER NOT NULL, 
    previous_hash VARCHAR(64) NOT NULL, 
    digest VARCHAR(64) NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(audit_id) REFERENCES audit_logs (id), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id), 
    UNIQUE (audit_id), 
    UNIQUE (organization_id, position)
);

CREATE INDEX ix_audit_seals_organization_id ON audit_seals (organization_id);

CREATE TABLE complaints (
    author_id VARCHAR(36) NOT NULL, 
    subject VARCHAR(200) NOT NULL, 
    body VARCHAR(4000) NOT NULL, 
    status VARCHAR NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, author_id) REFERENCES memberships (organization_id, user_id)
);

CREATE INDEX ix_complaints_organization_id ON complaints (organization_id);

CREATE TABLE incident_events (
    incident_id VARCHAR(36) NOT NULL, 
    event_id VARCHAR(36) NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, event_id) REFERENCES security_events (organization_id, id), 
    FOREIGN KEY(organization_id, incident_id) REFERENCES incidents (organization_id, id), 
    UNIQUE (organization_id, incident_id, event_id)
);

CREATE INDEX ix_incident_events_organization_id ON incident_events (organization_id);

CREATE TABLE integration_accounts (
    user_id VARCHAR(36) NOT NULL, 
    provider VARCHAR(30) NOT NULL, 
    external_id VARCHAR(200) NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, user_id) REFERENCES memberships (organization_id, user_id)
);

CREATE INDEX ix_integration_accounts_organization_id ON integration_accounts (organization_id);

CREATE TABLE project_comments (
    project_id VARCHAR(36) NOT NULL, 
    author_id VARCHAR(36) NOT NULL, 
    body VARCHAR(4000) NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, project_id) REFERENCES projects (organization_id, id)
);

CREATE INDEX ix_project_comments_organization_id ON project_comments (organization_id);

CREATE TABLE project_members (
    project_id VARCHAR(36) NOT NULL, 
    user_id VARCHAR(36) NOT NULL, 
    manager BOOLEAN NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, project_id) REFERENCES projects (organization_id, id), 
    FOREIGN KEY(organization_id, user_id) REFERENCES memberships (organization_id, user_id), 
    UNIQUE (organization_id, project_id, user_id)
);

CREATE INDEX ix_project_members_organization_id ON project_members (organization_id);

CREATE TABLE repository_projects (
    repository_id VARCHAR(36) NOT NULL, 
    project_id VARCHAR(36) NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, project_id) REFERENCES projects (organization_id, id), 
    FOREIGN KEY(organization_id, repository_id) REFERENCES repositories (organization_id, id), 
    UNIQUE (organization_id, repository_id, project_id)
);

CREATE INDEX ix_repository_projects_organization_id ON repository_projects (organization_id);

CREATE TABLE scan_jobs (
    repository_id VARCHAR(36) NOT NULL, 
    requested_by VARCHAR(36) NOT NULL, 
    request_key VARCHAR(100) NOT NULL, 
    commit_sha VARCHAR(40) NOT NULL, 
    status VARCHAR NOT NULL, 
    attempts INTEGER NOT NULL, 
    lease_until TIMESTAMP WITH TIME ZONE, 
    report JSON NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, repository_id) REFERENCES repositories (organization_id, id), 
    UNIQUE (organization_id, request_key)
);

CREATE INDEX ix_scan_jobs_organization_id ON scan_jobs (organization_id);

CREATE TABLE sprints (
    project_id VARCHAR(36) NOT NULL, 
    name VARCHAR(100) NOT NULL, 
    starts_on DATE NOT NULL, 
    ends_on DATE NOT NULL, 
    status VARCHAR NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    CHECK (ends_on >= starts_on), 
    FOREIGN KEY(organization_id, project_id) REFERENCES projects (organization_id, id), 
    UNIQUE (organization_id, id)
);

CREATE INDEX ix_sprints_organization_id ON sprints (organization_id);

CREATE TABLE identity_documents (
    employee_id VARCHAR(36) NOT NULL, 
    storage_key VARCHAR(300) NOT NULL, 
    media_type VARCHAR(100) NOT NULL, 
    digest VARCHAR(64) NOT NULL, 
    status VARCHAR NOT NULL, 
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    reviewed_by VARCHAR(36), 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, employee_id) REFERENCES employees (organization_id, id), 
    UNIQUE (storage_key)
);

CREATE INDEX ix_identity_documents_organization_id ON identity_documents (organization_id);

CREATE TABLE leave_requests (
    employee_id VARCHAR(36) NOT NULL, 
    starts_on DATE NOT NULL, 
    ends_on DATE NOT NULL, 
    reason VARCHAR(1000) NOT NULL, 
    status VARCHAR NOT NULL, 
    reviewed_by VARCHAR(36), 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    CHECK (ends_on >= starts_on), 
    FOREIGN KEY(organization_id, employee_id) REFERENCES employees (organization_id, id)
);

CREATE INDEX ix_leave_requests_organization_id ON leave_requests (organization_id);

CREATE TABLE lifecycle_plans (
    employee_id VARCHAR(36) NOT NULL, 
    kind VARCHAR(30) NOT NULL, 
    snapshot JSON NOT NULL, 
    proposed JSON NOT NULL, 
    proposed_by VARCHAR(36) NOT NULL, 
    approved_by VARCHAR(36), 
    status VARCHAR NOT NULL, 
    history JSON NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, employee_id) REFERENCES employees (organization_id, id)
);

CREATE INDEX ix_lifecycle_plans_organization_id ON lifecycle_plans (organization_id);

CREATE TABLE task_details (
    task_id VARCHAR(36) NOT NULL, 
    priority VARCHAR NOT NULL, 
    deadline TIMESTAMP WITH TIME ZONE, 
    sprint_id VARCHAR(36), 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, sprint_id) REFERENCES sprints (organization_id, id), 
    FOREIGN KEY(organization_id, task_id) REFERENCES tasks (organization_id, id), 
    UNIQUE (task_id)
);

CREATE INDEX ix_task_details_organization_id ON task_details (organization_id);

ALTER TABLE "ai_usage" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "ai_usage" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "ai_usage"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "budgets" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "budgets" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "budgets"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "cloud_assessments" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "cloud_assessments" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "cloud_assessments"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "cost_records" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "cost_records" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "cost_records"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "departments" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "departments" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "departments"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "detection_policies" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "detection_policies" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "detection_policies"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "audit_seals" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "audit_seals" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "audit_seals"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "complaints" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "complaints" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "complaints"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "incident_events" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "incident_events" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "incident_events"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "integration_accounts" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "integration_accounts" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "integration_accounts"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "project_comments" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "project_comments" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "project_comments"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "project_members" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "project_members" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "project_members"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "repository_projects" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "repository_projects" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "repository_projects"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "scan_jobs" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "scan_jobs" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "scan_jobs"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "sprints" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "sprints" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "sprints"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "identity_documents" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "identity_documents" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "identity_documents"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "leave_requests" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "leave_requests" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "leave_requests"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "lifecycle_plans" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "lifecycle_plans" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "lifecycle_plans"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "task_details" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "task_details" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "task_details"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

CREATE TRIGGER append_only BEFORE UPDATE OR DELETE ON audit_seals FOR EACH ROW EXECUTE FUNCTION mesh_deny_ledger_mutation();

UPDATE alembic_version SET version_num='0002' WHERE alembic_version.version_num = '0001';

-- Running upgrade 0002 -> 0003

CREATE UNIQUE INDEX uq_payroll_org_id ON payroll (organization_id, id);

CREATE TABLE payroll_rules (
    name VARCHAR(100) NOT NULL, 
    version INTEGER NOT NULL, 
    currency VARCHAR(3) NOT NULL, 
    components JSON NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    CHECK (version > 0), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id), 
    UNIQUE (organization_id, id), 
    UNIQUE (organization_id, name, version)
);

CREATE INDEX ix_payroll_rules_organization_id ON payroll_rules (organization_id);

CREATE TABLE payroll_calculations (
    payroll_id VARCHAR(36) NOT NULL, 
    rule_id VARCHAR(36) NOT NULL, 
    base NUMERIC(14, 2) NOT NULL, 
    breakdown JSON NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, payroll_id) REFERENCES payroll (organization_id, id), 
    FOREIGN KEY(organization_id, rule_id) REFERENCES payroll_rules (organization_id, id), 
    UNIQUE (payroll_id)
);

CREATE INDEX ix_payroll_calculations_organization_id ON payroll_calculations (organization_id);

ALTER TABLE "payroll_rules" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "payroll_rules" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "payroll_rules"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

ALTER TABLE "payroll_calculations" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "payroll_calculations" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "payroll_calculations"
                USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

CREATE TRIGGER append_only BEFORE UPDATE OR DELETE ON payroll_rules FOR EACH ROW EXECUTE FUNCTION mesh_deny_ledger_mutation();

UPDATE alembic_version SET version_num='0003' WHERE alembic_version.version_num = '0002';

-- Running upgrade 0003 -> 0004

CREATE TABLE job_roles (
    title VARCHAR(100) NOT NULL, 
    grade VARCHAR(40) NOT NULL, 
    version INTEGER NOT NULL, 
    currency VARCHAR(3) NOT NULL, 
    minimum_base NUMERIC(14, 2) NOT NULL, 
    maximum_base NUMERIC(14, 2) NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    CHECK (version > 0 AND minimum_base >= 0 AND maximum_base >= minimum_base), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id), 
    UNIQUE (organization_id, id), 
    UNIQUE (organization_id, title, grade, version)
);

CREATE INDEX ix_job_roles_organization_id ON job_roles (organization_id);

CREATE TABLE incident_notes (
    incident_id VARCHAR(36) NOT NULL, 
    author_id VARCHAR(36) NOT NULL, 
    body VARCHAR(4000) NOT NULL, 
    reference VARCHAR(200), 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, author_id) REFERENCES memberships (organization_id, user_id), 
    FOREIGN KEY(organization_id, incident_id) REFERENCES incidents (organization_id, id)
);

CREATE INDEX ix_incident_notes_organization_id ON incident_notes (organization_id);

CREATE TABLE employment_changes (
    employee_id VARCHAR(36) NOT NULL, 
    job_role_id VARCHAR(36) NOT NULL, 
    previous_terms_id VARCHAR(36), 
    base NUMERIC(14, 2) NOT NULL, 
    effective_on DATE NOT NULL, 
    reason VARCHAR(1000) NOT NULL, 
    proposed_by VARCHAR(36) NOT NULL, 
    reviewed_by VARCHAR(36), 
    status VARCHAR NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    CHECK (status IN ('proposed','approved','rejected','applied')), 
    CHECK (base >= 0), 
    FOREIGN KEY(organization_id, employee_id) REFERENCES employees (organization_id, id), 
    FOREIGN KEY(organization_id, job_role_id) REFERENCES job_roles (organization_id, id), 
    UNIQUE (organization_id, id)
);

CREATE INDEX ix_employment_changes_organization_id ON employment_changes (organization_id);

CREATE TABLE leave_entitlements (
    employee_id VARCHAR(36) NOT NULL, 
    year INTEGER NOT NULL, 
    allowance_days INTEGER NOT NULL, 
    counting VARCHAR(20) NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    CHECK (counting IN ('calendar','weekdays')), 
    CHECK (year BETWEEN 2000 AND 2200 AND allowance_days BETWEEN 0 AND 366), 
    FOREIGN KEY(organization_id, employee_id) REFERENCES employees (organization_id, id), 
    UNIQUE (organization_id, employee_id, year)
);

CREATE INDEX ix_leave_entitlements_organization_id ON leave_entitlements (organization_id);

CREATE TABLE employment_terms (
    employee_id VARCHAR(36) NOT NULL, 
    job_role_id VARCHAR(36) NOT NULL, 
    change_id VARCHAR(36) NOT NULL, 
    base NUMERIC(14, 2) NOT NULL, 
    currency VARCHAR(3) NOT NULL, 
    effective_on DATE NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    CHECK (base >= 0), 
    FOREIGN KEY(organization_id, change_id) REFERENCES employment_changes (organization_id, id), 
    FOREIGN KEY(organization_id, employee_id) REFERENCES employees (organization_id, id), 
    FOREIGN KEY(organization_id, job_role_id) REFERENCES job_roles (organization_id, id), 
    UNIQUE (change_id), 
    UNIQUE (organization_id, employee_id, effective_on)
);

CREATE INDEX ix_employment_terms_organization_id ON employment_terms (organization_id);

ALTER TABLE "job_roles" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "job_roles" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "job_roles"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

DO $mesh_grants$ BEGIN
                IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='anon') THEN
                    REVOKE ALL ON TABLE public."job_roles" FROM anon;
                END IF;
            END; $mesh_grants$;;

DO $mesh_grants$ BEGIN
                IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='authenticated') THEN
                    REVOKE ALL ON TABLE public."job_roles" FROM authenticated;
                END IF;
            END; $mesh_grants$;;

ALTER TABLE "employment_changes" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "employment_changes" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "employment_changes"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

DO $mesh_grants$ BEGIN
                IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='anon') THEN
                    REVOKE ALL ON TABLE public."employment_changes" FROM anon;
                END IF;
            END; $mesh_grants$;;

DO $mesh_grants$ BEGIN
                IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='authenticated') THEN
                    REVOKE ALL ON TABLE public."employment_changes" FROM authenticated;
                END IF;
            END; $mesh_grants$;;

ALTER TABLE "employment_terms" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "employment_terms" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "employment_terms"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

DO $mesh_grants$ BEGIN
                IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='anon') THEN
                    REVOKE ALL ON TABLE public."employment_terms" FROM anon;
                END IF;
            END; $mesh_grants$;;

DO $mesh_grants$ BEGIN
                IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='authenticated') THEN
                    REVOKE ALL ON TABLE public."employment_terms" FROM authenticated;
                END IF;
            END; $mesh_grants$;;

ALTER TABLE "leave_entitlements" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "leave_entitlements" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "leave_entitlements"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

DO $mesh_grants$ BEGIN
                IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='anon') THEN
                    REVOKE ALL ON TABLE public."leave_entitlements" FROM anon;
                END IF;
            END; $mesh_grants$;;

DO $mesh_grants$ BEGIN
                IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='authenticated') THEN
                    REVOKE ALL ON TABLE public."leave_entitlements" FROM authenticated;
                END IF;
            END; $mesh_grants$;;

ALTER TABLE "incident_notes" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "incident_notes" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "incident_notes"
            USING (organization_id = nullif(current_setting('mesh.organization_id', true), ''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id', true), ''));

DO $mesh_grants$ BEGIN
                IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='anon') THEN
                    REVOKE ALL ON TABLE public."incident_notes" FROM anon;
                END IF;
            END; $mesh_grants$;;

DO $mesh_grants$ BEGIN
                IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='authenticated') THEN
                    REVOKE ALL ON TABLE public."incident_notes" FROM authenticated;
                END IF;
            END; $mesh_grants$;;

CREATE TRIGGER append_only BEFORE UPDATE OR DELETE ON job_roles FOR EACH ROW EXECUTE FUNCTION mesh_deny_ledger_mutation();

CREATE TRIGGER append_only BEFORE UPDATE OR DELETE ON employment_terms FOR EACH ROW EXECUTE FUNCTION mesh_deny_ledger_mutation();

CREATE TRIGGER append_only BEFORE UPDATE OR DELETE ON incident_notes FOR EACH ROW EXECUTE FUNCTION mesh_deny_ledger_mutation();

CREATE TRIGGER append_only BEFORE UPDATE OR DELETE ON payroll_calculations FOR EACH ROW EXECUTE FUNCTION mesh_deny_ledger_mutation();

UPDATE alembic_version SET version_num='0004' WHERE alembic_version.version_num = '0003';

-- Running upgrade 0004 -> 0005

ALTER TABLE ai_usage ADD COLUMN model VARCHAR(100);

ALTER TABLE ai_usage ADD COLUMN billing_currency VARCHAR(3);

ALTER TABLE ai_usage ADD COLUMN pricing JSON;

UPDATE alembic_version SET version_num='0005' WHERE alembic_version.version_num = '0004';

-- Running upgrade 0005 -> 0006

CREATE TABLE identity_sessions (
    id VARCHAR(36) NOT NULL, 
    user_id VARCHAR(36) NOT NULL, 
    provider_session_id VARCHAR(36) NOT NULL, 
    client_hint VARCHAR(200) NOT NULL, 
    ip_digest VARCHAR(64) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    last_seen TIMESTAMP WITH TIME ZONE NOT NULL, 
    expires_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    revoked_at TIMESTAMP WITH TIME ZONE, 
    revocation_reason VARCHAR(40), 
    PRIMARY KEY (id), 
    UNIQUE (user_id, provider_session_id)
);

CREATE INDEX ix_identity_sessions_user_id ON identity_sessions (user_id);

ALTER TABLE "identity_sessions" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "identity_sessions" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "identity_sessions"
            USING (user_id = nullif(current_setting('mesh.user_id',true),''))
            WITH CHECK (user_id = nullif(current_setting('mesh.user_id',true),''));

DO $mesh_session_grants$ BEGIN
                IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='anon') THEN
                    REVOKE ALL ON TABLE public.identity_sessions FROM anon;
                END IF;
            END; $mesh_session_grants$;;

DO $mesh_session_grants$ BEGIN
                IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='authenticated') THEN
                    REVOKE ALL ON TABLE public.identity_sessions FROM authenticated;
                END IF;
            END; $mesh_session_grants$;;

UPDATE alembic_version SET version_num='0006' WHERE alembic_version.version_num = '0005';

-- Running upgrade 0006 -> 0007

CREATE TABLE webhook_deliveries (
    provider VARCHAR(30) NOT NULL, 
    delivery_id VARCHAR(36) NOT NULL, 
    event VARCHAR(50) NOT NULL, 
    payload_digest VARCHAR(64) NOT NULL, 
    result JSON NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id), 
    UNIQUE (organization_id, provider, delivery_id), 
    UNIQUE (organization_id, provider, payload_digest)
);

CREATE INDEX ix_webhook_deliveries_organization_id ON webhook_deliveries (organization_id);

ALTER TABLE "webhook_deliveries" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "webhook_deliveries" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "webhook_deliveries"
            USING (organization_id = nullif(current_setting('mesh.organization_id',true),''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id',true),''));

CREATE TRIGGER append_only BEFORE UPDATE OR DELETE ON webhook_deliveries FOR EACH ROW EXECUTE FUNCTION mesh_deny_ledger_mutation();

DO $mesh_webhook_grants$ BEGIN
                IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='anon') THEN
                    REVOKE ALL ON TABLE public.webhook_deliveries FROM anon;
                END IF;
            END; $mesh_webhook_grants$;;

DO $mesh_webhook_grants$ BEGIN
                IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='authenticated') THEN
                    REVOKE ALL ON TABLE public.webhook_deliveries FROM authenticated;
                END IF;
            END; $mesh_webhook_grants$;;

UPDATE alembic_version SET version_num='0007' WHERE alembic_version.version_num = '0006';

-- Running upgrade 0007 -> 0008

ALTER TABLE cloud_assessments ADD COLUMN errors JSON;

ALTER TABLE cloud_assessments ADD COLUMN coverage JSON;

ALTER TABLE cloud_assessments ADD COLUMN limitations JSON;

CREATE TRIGGER append_only BEFORE UPDATE OR DELETE ON cloud_assessments FOR EACH ROW EXECUTE FUNCTION mesh_deny_ledger_mutation();

UPDATE alembic_version SET version_num='0008' WHERE alembic_version.version_num = '0007';

-- Running upgrade 0008 -> 0009

ALTER TABLE projects ADD COLUMN approval_policy JSON;

CREATE TABLE project_approval_policies (
    version INTEGER NOT NULL, 
    required_senior_reviews INTEGER NOT NULL, 
    reviewers_must_be_members BOOLEAN NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id) REFERENCES organizations (id), 
    UNIQUE (organization_id, version), 
    CHECK (version > 0 AND required_senior_reviews BETWEEN 1 AND 5)
);

CREATE INDEX ix_project_approval_policies_organization_id ON project_approval_policies (organization_id);

CREATE TABLE project_reviews (
    project_id VARCHAR(36) NOT NULL, 
    reviewer_id VARCHAR(36) NOT NULL, 
    comment VARCHAR(2000) NOT NULL, 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, project_id) REFERENCES projects (organization_id, id), 
    FOREIGN KEY(organization_id, reviewer_id) REFERENCES memberships (organization_id, user_id), 
    UNIQUE (organization_id, project_id, reviewer_id)
);

CREATE INDEX ix_project_reviews_organization_id ON project_reviews (organization_id);

ALTER TABLE "project_approval_policies" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "project_approval_policies" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "project_approval_policies"
                USING (organization_id = nullif(current_setting('mesh.organization_id',true),''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id',true),''));

CREATE TRIGGER append_only BEFORE UPDATE OR DELETE ON project_approval_policies FOR EACH ROW EXECUTE FUNCTION mesh_deny_ledger_mutation();

DO $mesh_project_grants$ BEGIN
                    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='anon') THEN
                        REVOKE ALL ON TABLE public."project_approval_policies" FROM anon;
                    END IF;
                END; $mesh_project_grants$;;

DO $mesh_project_grants$ BEGIN
                    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='authenticated') THEN
                        REVOKE ALL ON TABLE public."project_approval_policies" FROM authenticated;
                    END IF;
                END; $mesh_project_grants$;;

ALTER TABLE "project_reviews" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "project_reviews" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "project_reviews"
                USING (organization_id = nullif(current_setting('mesh.organization_id',true),''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id',true),''));

CREATE TRIGGER append_only BEFORE UPDATE OR DELETE ON project_reviews FOR EACH ROW EXECUTE FUNCTION mesh_deny_ledger_mutation();

DO $mesh_project_grants$ BEGIN
                    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='anon') THEN
                        REVOKE ALL ON TABLE public."project_reviews" FROM anon;
                    END IF;
                END; $mesh_project_grants$;;

DO $mesh_project_grants$ BEGIN
                    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='authenticated') THEN
                        REVOKE ALL ON TABLE public."project_reviews" FROM authenticated;
                    END IF;
                END; $mesh_project_grants$;;

UPDATE alembic_version SET version_num='0009' WHERE alembic_version.version_num = '0008';

-- Running upgrade 0009 -> 0010

CREATE UNIQUE INDEX uq_cloud_assessments_org_id ON cloud_assessments (organization_id, id);

CREATE TABLE cloud_assessment_jobs (
    requested_by VARCHAR(36) NOT NULL, 
    request_key VARCHAR(100) NOT NULL, 
    provider VARCHAR(20) NOT NULL, 
    status VARCHAR(20) NOT NULL, 
    attempts INTEGER NOT NULL, 
    lease_until TIMESTAMP WITH TIME ZONE, 
    assessment_id VARCHAR(36), 
    error_code VARCHAR(50), 
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, requested_by) REFERENCES memberships (organization_id, user_id), 
    FOREIGN KEY(organization_id, assessment_id) REFERENCES cloud_assessments (organization_id, id), 
    UNIQUE (organization_id, request_key), 
    CHECK (status IN ('queued','running','completed','dead_letter','cancelled')), 
    CHECK (attempts >= 0 AND attempts <= 3)
);

CREATE INDEX ix_cloud_assessment_jobs_organization_id ON cloud_assessment_jobs (organization_id);

ALTER TABLE "cloud_assessment_jobs" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "cloud_assessment_jobs" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "cloud_assessment_jobs"
            USING (organization_id = nullif(current_setting('mesh.organization_id',true),''))
            WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id',true),''));

DO $mesh_cloud_job_grants$ BEGIN
                IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='anon') THEN
                    REVOKE ALL ON TABLE public.cloud_assessment_jobs FROM anon;
                END IF;
            END; $mesh_cloud_job_grants$;;

DO $mesh_cloud_job_grants$ BEGIN
                IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='authenticated') THEN
                    REVOKE ALL ON TABLE public.cloud_assessment_jobs FROM authenticated;
                END IF;
            END; $mesh_cloud_job_grants$;;

UPDATE alembic_version SET version_num='0010' WHERE alembic_version.version_num = '0009';

-- Running upgrade 0010 -> 0011

CREATE FUNCTION public.mesh_retire_telemetry(retention_days integer, batch_size integer)
    RETURNS integer LANGUAGE plpgsql SECURITY DEFINER
    SET search_path = pg_catalog
    AS $mesh_retention$
    DECLARE
        scoped_org text := nullif(current_setting('mesh.organization_id', true), '');
        candidates text[];
        removed integer := 0;
    BEGIN
        IF scoped_org IS NULL OR retention_days IS NULL OR batch_size IS NULL
            OR retention_days < 30 OR retention_days > 3650 OR batch_size < 1 OR batch_size > 1000 THEN
            RAISE EXCEPTION 'Explicit tenant and bounded retention policy required';
        END IF;
        PERFORM id FROM public.organizations WHERE id=scoped_org FOR NO KEY UPDATE;
        IF NOT FOUND THEN RAISE EXCEPTION 'Retention tenant not found'; END IF;
        SELECT array_agg(selected.id) INTO candidates FROM (
            SELECT e.id FROM public.security_events e
            WHERE e.organization_id=scoped_org
                AND e.occurred_at < now() - make_interval(days => retention_days)
                AND NOT EXISTS (
                    SELECT 1 FROM public.incident_events link
                    WHERE link.organization_id=scoped_org AND link.event_id=e.id
                )
                AND NOT EXISTS (
                    SELECT 1 FROM public.incidents i
                    WHERE i.organization_id=scoped_org AND i.event_ids::jsonb ? e.id
                )
            ORDER BY e.occurred_at,e.id LIMIT batch_size FOR UPDATE OF e SKIP LOCKED
        ) selected;
        IF candidates IS NULL THEN RETURN 0; END IF;
        DELETE FROM public.anomalies WHERE organization_id=scoped_org AND event_id=ANY(candidates);
        DELETE FROM public.security_events WHERE organization_id=scoped_org AND id=ANY(candidates);
        GET DIAGNOSTICS removed = ROW_COUNT;
        RETURN removed;
    END;
    $mesh_retention$;;

REVOKE ALL ON FUNCTION public.mesh_retire_telemetry(integer,integer) FROM PUBLIC;

UPDATE alembic_version SET version_num='0011' WHERE alembic_version.version_num = '0010';

-- Running upgrade 0011 -> 0012

ALTER TABLE employment_changes ADD COLUMN resolution_reason VARCHAR(1000);

ALTER TABLE employment_changes ADD COLUMN resolved_at TIMESTAMP WITH TIME ZONE;

UPDATE alembic_version SET version_num='0012' WHERE alembic_version.version_num = '0011';

-- Running upgrade 0012 -> 0013

ALTER TABLE leave_entitlements ADD COLUMN holidays JSON DEFAULT '[]' NOT NULL;

UPDATE alembic_version SET version_num='0013' WHERE alembic_version.version_num = '0012';

-- Running upgrade 0013 -> 0014

CREATE INDEX ix_event_org_time_id ON security_events (organization_id, occurred_at, id);

CREATE TABLE risk_policies (
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    version INTEGER NOT NULL, 
    created_by VARCHAR(36) NOT NULL, 
    algorithm_version VARCHAR(40) NOT NULL, 
    weights JSON NOT NULL, 
    thresholds JSON NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, created_by) REFERENCES memberships (organization_id, user_id), 
    UNIQUE (organization_id, id), 
    UNIQUE (organization_id, version), 
    CHECK (version > 0)
);

CREATE TABLE risk_assessments (
    id VARCHAR(36) NOT NULL, 
    organization_id VARCHAR(36) NOT NULL, 
    created_at TIMESTAMP WITH TIME ZONE NOT NULL, 
    policy_id VARCHAR(36) NOT NULL, 
    requested_by VARCHAR(36) NOT NULL, 
    request_key VARCHAR(100) NOT NULL, 
    request_digest VARCHAR(64) NOT NULL, 
    window_start TIMESTAMP WITH TIME ZONE NOT NULL, 
    window_end TIMESTAMP WITH TIME ZONE NOT NULL, 
    synthetic BOOLEAN NOT NULL, 
    result JSON NOT NULL, 
    PRIMARY KEY (id), 
    FOREIGN KEY(organization_id, policy_id) REFERENCES risk_policies (organization_id, id), 
    FOREIGN KEY(organization_id, requested_by) REFERENCES memberships (organization_id, user_id), 
    UNIQUE (organization_id, request_key), 
    CHECK (window_start <= window_end)
);

CREATE INDEX ix_risk_assessment_window ON risk_assessments (organization_id, synthetic, window_end, window_start);

CREATE INDEX ix_risk_policies_organization_id ON risk_policies (organization_id);

REVOKE ALL ON TABLE public."risk_policies" FROM PUBLIC;

ALTER TABLE "risk_policies" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "risk_policies" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "risk_policies"
                USING (organization_id = nullif(current_setting('mesh.organization_id',true),''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id',true),''));

CREATE TRIGGER append_only BEFORE UPDATE OR DELETE ON risk_policies FOR EACH ROW EXECUTE FUNCTION mesh_deny_ledger_mutation();

DO $mesh_risk$ BEGIN
                    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='anon') THEN
                        REVOKE ALL ON TABLE public."risk_policies" FROM anon;
                    END IF;
                END; $mesh_risk$;;

DO $mesh_risk$ BEGIN
                    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='authenticated') THEN
                        REVOKE ALL ON TABLE public."risk_policies" FROM authenticated;
                    END IF;
                END; $mesh_risk$;;

DO $mesh_risk_runtime$ BEGIN
                IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='mesh_runtime') THEN
                    GRANT SELECT, INSERT ON TABLE public."risk_policies" TO mesh_runtime;
                    REVOKE UPDATE, DELETE ON TABLE public."risk_policies" FROM mesh_runtime;
                END IF;
            END; $mesh_risk_runtime$;;

CREATE INDEX ix_risk_assessments_organization_id ON risk_assessments (organization_id);

REVOKE ALL ON TABLE public."risk_assessments" FROM PUBLIC;

ALTER TABLE "risk_assessments" ENABLE ROW LEVEL SECURITY;

ALTER TABLE "risk_assessments" FORCE ROW LEVEL SECURITY;

CREATE POLICY tenant_boundary ON "risk_assessments"
                USING (organization_id = nullif(current_setting('mesh.organization_id',true),''))
                WITH CHECK (organization_id = nullif(current_setting('mesh.organization_id',true),''));

CREATE TRIGGER append_only BEFORE UPDATE OR DELETE ON risk_assessments FOR EACH ROW EXECUTE FUNCTION mesh_deny_ledger_mutation();

DO $mesh_risk$ BEGIN
                    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='anon') THEN
                        REVOKE ALL ON TABLE public."risk_assessments" FROM anon;
                    END IF;
                END; $mesh_risk$;;

DO $mesh_risk$ BEGIN
                    IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='authenticated') THEN
                        REVOKE ALL ON TABLE public."risk_assessments" FROM authenticated;
                    END IF;
                END; $mesh_risk$;;

DO $mesh_risk_runtime$ BEGIN
                IF EXISTS (SELECT 1 FROM pg_roles WHERE rolname='mesh_runtime') THEN
                    GRANT SELECT, INSERT ON TABLE public."risk_assessments" TO mesh_runtime;
                    REVOKE UPDATE, DELETE ON TABLE public."risk_assessments" FROM mesh_runtime;
                END IF;
            END; $mesh_risk_runtime$;;

CREATE OR REPLACE FUNCTION public.mesh_retire_telemetry(retention_days integer, batch_size integer)
        RETURNS integer LANGUAGE plpgsql SECURITY DEFINER
        SET search_path = pg_catalog
        AS $mesh_retention$
        DECLARE
            scoped_org text := nullif(current_setting('mesh.organization_id', true), '');
            candidates text[];
            removed integer := 0;
        BEGIN
            IF scoped_org IS NULL OR retention_days IS NULL OR batch_size IS NULL
                OR retention_days < 30 OR retention_days > 3650 OR batch_size < 1 OR batch_size > 1000 THEN
                RAISE EXCEPTION 'Explicit tenant and bounded retention policy required';
            END IF;
            PERFORM id FROM public.organizations WHERE id=scoped_org FOR NO KEY UPDATE;
            IF NOT FOUND THEN RAISE EXCEPTION 'Retention tenant not found'; END IF;
            SELECT array_agg(selected.id) INTO candidates FROM (
                SELECT e.id FROM public.security_events e
                WHERE e.organization_id=scoped_org
                    AND e.occurred_at < now() - make_interval(days => retention_days)
                    AND NOT EXISTS (
                        SELECT 1 FROM public.incident_events link
                        WHERE link.organization_id=scoped_org AND link.event_id=e.id
                    )
                    AND NOT EXISTS (
                        SELECT 1 FROM public.incidents i
                        WHERE i.organization_id=scoped_org AND i.event_ids::jsonb ? e.id
                    )
                    AND NOT EXISTS (
                        SELECT 1 FROM public.risk_assessments r
                        WHERE r.organization_id=scoped_org AND r.synthetic=e.synthetic
                            AND e.occurred_at >= r.window_start AND e.occurred_at <= r.window_end
                    )
                ORDER BY e.occurred_at,e.id LIMIT batch_size FOR UPDATE OF e SKIP LOCKED
            ) selected;
            IF candidates IS NULL THEN RETURN 0; END IF;
            DELETE FROM public.anomalies WHERE organization_id=scoped_org AND event_id=ANY(candidates);
            DELETE FROM public.security_events WHERE organization_id=scoped_org AND id=ANY(candidates);
            GET DIAGNOSTICS removed = ROW_COUNT;
            RETURN removed;
        END;
        $mesh_retention$;;

REVOKE ALL ON FUNCTION public.mesh_retire_telemetry(integer,integer) FROM PUBLIC;

UPDATE alembic_version SET version_num='0014' WHERE alembic_version.version_num = '0013';

COMMIT;


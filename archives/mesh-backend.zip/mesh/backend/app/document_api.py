from uuid import UUID

from fastapi import APIRouter, HTTPException, Request
from starlette.concurrency import run_in_threadpool

from app.api import DB, P
from app.core.config import settings
from app.core.time import as_utc
from app.document_ocr import Suggestions, cipher, decrypt, pending
from app.documents import PrivateStorage, expire, store
from app.enterprise_api import HR
from app.enterprise_schemas import Decision, DocumentOutput, SignedDocument
from app.models import Employee, IdentityDocument, now
from app.services import audit, emit, scoped

router = APIRouter(prefix="/api/v1")


@router.post(
    "/employees/{employee_id}/identity-documents", response_model=DocumentOutput, status_code=201
)
async def upload(employee_id: UUID, request: Request, db: DB, p: P):
    employee = scoped(db, Employee, p, str(employee_id))
    if employee.user_id != p.user_id:
        raise HTTPException(403, "Only the employee may upload their identity document")
    content = await request.body()
    return await run_in_threadpool(
        store, db, p, employee.id, request.headers.get("content-type", ""), content
    )


@router.get("/hr/identity-documents/{document_id}/signed-url", response_model=SignedDocument)
def signed_url(document_id: UUID, db: DB, p: HR):
    record = scoped(db, IdentityDocument, p, str(document_id))
    if record.status == "deleted" or as_utc(record.expires_at) <= now():
        raise HTTPException(410, "Identity document expired")
    audit(db, p, "employee.document.access", record.id)
    return SignedDocument(url=PrivateStorage().sign(record.storage_key))


@router.post("/hr/identity-documents/{document_id}/decision", response_model=DocumentOutput)
def review(document_id: UUID, data: Decision, db: DB, p: HR):
    record = scoped(db, IdentityDocument, p, str(document_id), lock=True)
    employee = scoped(db, Employee, p, record.employee_id, lock=True)
    if (
        employee.user_id == p.user_id
        or record.status != "pending_hr"
        or as_utc(record.expires_at) <= now()
    ):
        raise HTTPException(409, "Independent HR review of an unexpired pending document required")
    if record.ocr_status in {"queued", "running"}:
        raise HTTPException(409, "Wait for OCR or explicitly select manual review")
    record.status, record.reviewed_by = data.decision, p.user_id
    employee.verification_status = data.decision
    emit(
        db,
        p,
        "employee.verified" if data.decision == "approved" else "employee.verification.rejected",
        employee.id,
    )
    return record


@router.get("/hr/identity-documents/{document_id}/ocr", response_model=Suggestions | None)
def ocr_result(document_id: UUID, db: DB, p: HR):
    record = scoped(db, IdentityDocument, p, str(document_id))
    if record.status == "deleted" or as_utc(record.expires_at) <= now():
        raise HTTPException(410, "Identity document expired")
    audit(db, p, "employee.document.ocr_access", record.id)
    return decrypt(record)


@router.post("/hr/identity-documents/{document_id}/ocr/retry", response_model=DocumentOutput)
def retry_ocr(document_id: UUID, db: DB, p: HR):
    if not settings().document_ocr_enabled:
        raise HTTPException(503, "Private OCR is not enabled")
    cipher()
    record = scoped(db, IdentityDocument, p, str(document_id), lock=True)
    pending(record)
    if record.ocr_status not in {"failed", "cancelled", "not_configured", "manual_review"}:
        raise HTTPException(409, "OCR is already pending or completed")
    record.ocr_status, record.ocr_attempts = "queued", 0
    record.ocr_lease_until, record.ocr_ciphertext, record.ocr_error_code = None, None, None
    record.ocr_completed_at = None
    audit(db, p, "employee.document.ocr_retry", record.id)
    return record


@router.post(
    "/hr/identity-documents/{document_id}/ocr/manual-review", response_model=DocumentOutput
)
def manual_ocr(document_id: UUID, db: DB, p: HR):
    record = scoped(db, IdentityDocument, p, str(document_id), lock=True)
    pending(record)
    employee = scoped(db, Employee, p, record.employee_id, lock=True)
    if employee.user_id == p.user_id:
        raise HTTPException(409, "Independent HR review required")
    record.ocr_status, record.ocr_ciphertext, record.ocr_lease_until = "manual_review", None, None
    record.ocr_error_code, record.ocr_completed_at = None, None
    audit(db, p, "employee.document.ocr_manual_review", record.id)
    return record


@router.post("/hr/identity-documents/expire")
def expire_documents(db: DB, p: HR) -> dict[str, int]:
    return {"expired": expire(db, p)}

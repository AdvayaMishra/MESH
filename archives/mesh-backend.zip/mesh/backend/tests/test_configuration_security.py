import pytest
from app.core.config import Settings
from pydantic import ValidationError


def test_configuration_errors_and_representations_do_not_expose_database_passwords():
    secret = "FIXTURE_PRIVATE_PASSWORD"
    with pytest.raises(ValidationError) as exc:
        Settings(
            _env_file=None,
            environment="production",
            test_mode=False,
            supabase_url="https://identity.example.org",
            require_privileged_mfa=True,
            auth_rate_secret="a" * 48,
            database_url=f"postgresql+psycopg://user:{secret}@database.example.org/mesh",
        )
    assert secret not in str(exc.value)
    assert "verified TLS" in str(exc.value)
    config = Settings(
        _env_file=None, database_url=f"postgresql://user:{secret}@database.example.org/mesh"
    )
    assert config.database_url.startswith("postgresql+psycopg://")
    assert secret not in repr(config)


def test_production_accepts_an_explicit_verified_postgres_connection():
    config = Settings(
        _env_file=None,
        environment="production",
        test_mode=False,
        supabase_url="https://identity.example.org",
        require_privileged_mfa=True,
        auth_rate_secret="a" * 48,
        database_url="postgresql+psycopg://runtime:fixture@database.example.org/mesh?sslmode=verify-full&sslrootcert=system",
    )
    assert config.environment == "production"

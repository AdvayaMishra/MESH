# Authentication

Supabase Auth is the only credential authority. Configure email confirmation, short-lived numeric signup OTP templates, secure SMTP, CAPTCHA verification, OTP resend intervals/attempt caps, refresh reuse detection, password strength and privileged-user MFA in Supabase. Those controls are not automatically provided by application configuration.

`POST /api/v1/auth/register` forwards email/password/CAPTCHA to Supabase. `verify` exchanges email/token/type for provider-issued tokens. `login`, `refresh`, `recover` and `logout` proxy provider operations with bounded timeouts and generic errors. `PUT /auth/password` completes authenticated password changes/recovery. REQUIRE_PRIVILEGED_MFA enforces verified JWT aal2 for Owner/HR/Security Analyst and is mandatory in production configuration. Backend MFA and observed-session inventory/revocation routes are implemented below; client device hints are untrusted observations. Owner creates an organization only after successful email confirmation.

Bearer access tokens must use ES256 or RS256, match the configured issuer and `authenticated` audience, include subject/iat/exp, and resolve to a confirmed email through `/auth/v1/user`. HS256 compatibility mode is deliberately unsupported. Rotate Supabase asymmetric signing keys using provider JWKS. The key cache lives for five minutes; token expiry is checked on every request.

Tenant selection requires `X-Organization-ID`. Active membership and active organization status are checked on each request; the ID alone never grants access. Invitations may be accepted before membership exists, using the verified identity plus token, email binding, single-use row lock and selected organization. Organization registration bootstrap is the other membership-free operation.

The backend uses bearer tokens, not auth cookies, so it does not create a cookie/CSRF contract. A future frontend choosing cookies needs its own secure HttpOnly/Secure/SameSite and CSRF design. Do not store service-role keys in frontend code. Global logout revokes provider refresh sessions; access-token invalidation is bounded by token expiry. No claim of instant provider JWT revocation is made.

## Durable MESH session controls

Verified tokens now require a UUID session_id. Account-security metadata is self-owned with user-context RLS and is never exposed to an organization owner for another user. MESH immediately denies a revoked observed session across organization contexts, independent of token expiration. Revoke-one/revoke-others affect MESH observations; provider refresh revocation remains separate. Logout returns HTTP 200 with local count and provider confirmed/unavailable status; local revocation commits even when the provider is unavailable. Password changes revoke other observed MESH sessions. Current client hints are untrusted metadata; raw IPs, access tokens and refresh tokens are not stored in session rows. Tombstone retention and provider-wide session verification require operational privacy review before production.

## TOTP and session contract

The /api/v1/auth/mfa routes list factors, enroll TOTP, create a challenge, verify six-digit codes and remove an owned factor. Verification returns provider tokens; clients must replace their previous bearer token. Enrollment provisioning data is sensitive: never log it or insert provider SVG directly as executable markup. Supabase remains the factor authority. Removing a verified factor requires aal2 and revokes observed MESH sessions; sign in again. Logout returns HTTP 200 with mesh_sessions_revoked and provider_logout (confirmed/unavailable). Local session denial remains effective when provider logout fails; unseen provider sessions are outside the local ledger. Hosted provider acceptance now creates and removes a temporary Auth user and real TOTP factor; see docs/supabase-provider-results.json.

Provider references: [Supabase TOTP](https://supabase.com/docs/guides/auth/auth-mfa/totp), [factor enrollment](https://supabase.com/docs/reference/javascript/auth-mfa-enroll).

TOTP enrollment accepts provider QR SVG strings up to 1 MiB within a 1 MiB streamed response bound. Other provider Auth responses remain capped at 128 KiB. Do not insert SVG as executable markup or log provisioning secrets. The test machine clock was ahead of the provider; synthetic fixture code generation used HTTPS provider time. Keep deployment and authenticator clocks synchronized; production JWT verification was not relaxed.

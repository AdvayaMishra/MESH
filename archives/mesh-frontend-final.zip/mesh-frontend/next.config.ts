import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  experimental: { workerThreads: true, cpus: 2 },
  turbopack: {
    rules: {
      "*.css": {
        loaders: ["@tailwindcss/turbopack"],
        as: "*.css",
      },
    },
  },
};

export default nextConfig;

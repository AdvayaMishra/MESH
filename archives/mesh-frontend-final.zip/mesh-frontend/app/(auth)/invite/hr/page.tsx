import { InviteForm } from "@/components/features/auth/invite-form";
export default function Page() { return <InviteForm kind="hr" />; }

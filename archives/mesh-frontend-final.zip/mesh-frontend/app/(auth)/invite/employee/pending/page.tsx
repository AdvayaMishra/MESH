"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { CheckCircle2, Clock, UserCheck } from "lucide-react";
import { AuthShell } from "@/components/features/auth/auth-shell";
import { employeeSteps } from "@/components/features/auth/stepper";
import { Button } from "@/components/ui/button";
import { useDataset } from "@/lib/api";
import { useWorkspace } from "@/stores/workspace-store";
import { useUI } from "@/stores/ui-store";
import { Badge } from "@/components/ui/badge";

export default function PendingReviewPage() {
  const router = useRouter();
  const { employees } = useDataset();
  const invitee = employees.find((e) => e.status === "Onboarding");
  const record = useWorkspace((s) => s.idSubmissions.find((item) => item.employee === invitee?.id));
  const approved = record?.status === "Approved";
  return (
    <AuthShell title={approved ? "Review complete" : "Waiting for a human review"} subtitle={approved ? "A reviewer confirmed your details. You can activate your account." : "Open the demo review workspace to complete an independent human decision. No email is sent."} steps={employeeSteps} current={2} simulated>
      <div className="space-y-4">
        <div className="rounded-2xl border border-line bg-white p-5">
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold">Review status</p>
            {approved ? <Badge tone="mint" dot>Approved by reviewer (demo)</Badge> : <Badge tone="amber" dot>Pending review</Badge>}
          </div>
          <ol className="mt-4 space-y-3 text-sm">
            <li className="flex items-center gap-3 text-ink"><CheckCircle2 className="size-5 text-mint" /> ID submitted</li>
            <li className="flex items-center gap-3 text-ink"><CheckCircle2 className="size-5 text-mint" /> Synthetic sample fields prepared (no OCR)</li>
            <li className="flex items-center gap-3 text-ink">{approved ? <CheckCircle2 className="size-5 text-mint" /> : <Clock className="size-5 animate-pulse text-amber" />} {approved ? `Reviewed by ${record?.history[0]?.by ?? "a demo reviewer"}` : "Waiting for an independent demo reviewer"}</li>
          </ol>
          <p className="mt-4 text-xs text-ink-2">Review decisions update this preview from the HR workspace. No delivery time or email is provided in this demo.</p>
        </div>
        {!approved ? (
          <Button variant="secondary" size="lg" className="w-full" onClick={() => { useUI.getState().setRole("hr"); router.push("/people/verification"); }}><UserCheck /> Open demo reviewer workspace</Button>
        ) : (
          <Button variant="gradient" size="lg" className="w-full" onClick={() => router.push("/invite/employee/activate")}>Continue to activation</Button>
        )}
        <Button variant="ghost" className="w-full" asChild><Link href="/login">Back to log in</Link></Button>
      </div>
    </AuthShell>
  );
}

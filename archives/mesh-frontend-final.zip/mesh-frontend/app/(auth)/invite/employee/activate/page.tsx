"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { PartyPopper } from "lucide-react";
import { AuthShell } from "@/components/features/auth/auth-shell";
import { employeeSteps } from "@/components/features/auth/stepper";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { useDataset } from "@/lib/api";
import { useWorkspace } from "@/stores/workspace-store";
import { useTenant } from "@/stores/tenant-store";
import { usePreferences } from "@/stores/preferences-store";
import { roleHome } from "@/lib/permissions";
import { toast } from "sonner";
import { useUI } from "@/stores/ui-store";

export default function ActivatePage() {
  const router = useRouter();
  const { employees } = useDataset();
  const invitee = employees.find((e) => e.status === "Onboarding");
  const approved = useWorkspace((s) => s.idSubmissions.some((v) => v.employee === invitee?.id && v.status === "Approved"));
  const org = useTenant((s) => s.orgId);
  const setRole = useUI((s) => s.setRole);
  const [mfa, setMfa] = React.useState(true);
  const [email, setEmail] = React.useState(true);
  return (
    <AuthShell title="Activate your account" subtitle="Last step. Choose how you want to stay secure and informed." steps={employeeSteps} current={3} simulated>
      <div className="space-y-4">
        {!approved && <p role="alert" className="text-sm text-coral">Complete the demo ID review before activation. No external account or MFA factor is created.</p>}
        <div className="flex items-center gap-3 rounded-2xl border border-line bg-white p-4">
          <div className="flex-1"><p className="text-sm font-semibold">Two-factor authentication</p><p className="text-xs text-ink-2">Recommended for everyone. Set up an authenticator app after activation.</p></div>
          <Switch checked={mfa} onCheckedChange={setMfa} aria-label="Two-factor authentication" />
        </div>
        <div className="flex items-center gap-3 rounded-2xl border border-line bg-white p-4">
          <div className="flex-1"><p className="text-sm font-semibold">Email notifications</p><p className="text-xs text-ink-2">Approvals, assigned tasks and security alerts.</p></div>
          <Switch checked={email} onCheckedChange={setEmail} aria-label="Email notifications" />
        </div>
        <Button variant="gradient" size="lg" className="w-full" disabled={!approved || !invitee} onClick={() => { if (!approved || !invitee) { toast.error("A human demo reviewer must approve the ID first."); return; } const preferences = usePreferences.getState(); preferences.selectPersona(org, invitee.appRole, invitee.id); preferences.setPreference(org, invitee.appRole, "Two-factor authentication", mfa); preferences.setPreference(org, invitee.appRole, "Approval requests", email); setRole(invitee.appRole); router.push(roleHome[invitee.appRole]); }}><PartyPopper /> Activate and open workspace</Button>
      </div>
    </AuthShell>
  );
}

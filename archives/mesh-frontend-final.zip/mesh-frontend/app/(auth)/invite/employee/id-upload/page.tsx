"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { FileImage, Lock, ScanLine, Trash2, UploadCloud } from "lucide-react";
import { toast } from "sonner";
import { AuthShell } from "@/components/features/auth/auth-shell";
import { employeeSteps } from "@/components/features/auth/stepper";
import { Button } from "@/components/ui/button";
import { Badge, SimulatedTag } from "@/components/ui/badge";
import { useDataset } from "@/lib/api";
import { useWorkspace } from "@/stores/workspace-store";
import { cn } from "@/lib/utils/cn";

const MAX = 5 * 1024 * 1024;
const OK = ["image/jpeg", "image/png", "application/pdf"];

export default function IdUploadPage() {
  const router = useRouter();
  const { employees } = useDataset();
  const invitee = employees.find((e) => e.status === "Onboarding");
  const submitDemoId = useWorkspace((s) => s.submitDemoId);
  const inputRef = React.useRef<HTMLInputElement>(null);
  const [file, setFile] = React.useState<File | null>(null);
  const [preview, setPreview] = React.useState<string | null>(null);
  const [drag, setDrag] = React.useState(false);
  const [error, setError] = React.useState("");
  const [scan, setScan] = React.useState<"idle" | "scanning" | "done">("idle");

  React.useEffect(() => () => { if (preview) URL.revokeObjectURL(preview); }, [preview]);

  function accept(f: File | undefined) {
    if (!f) return;
    if (!OK.includes(f.type)) return setError("Upload a JPG, PNG or PDF file.");
    if (f.size > MAX) return setError("File is larger than 5 MB. Try a smaller scan.");
    setError("");
    setFile(f);
    setPreview(f.type.startsWith("image/") ? URL.createObjectURL(f) : null);
    setScan("scanning");

  }

  React.useEffect(() => {
    if (!file) return;
    const timer = window.setTimeout(() => setScan("done"), 1800);
    return () => window.clearTimeout(timer);
  }, [file]);

  function clear() {
    setFile(null);
    setPreview(null);
    setScan("idle");
  }

  const fields = [["Full name", invitee?.name ?? "No onboarding employee", 0], ["Date of birth", "Sample only", 0], ["ID number", "Masked demo value", 0], ["Expiry", "Sample only", 0]] as const;

  return (
    <AuthShell wide title="Upload your ID" subtitle="A member of the People team will review it before your account is activated." steps={employeeSteps} current={1} simulated>
      <div className="space-y-5">
        {!file ? (
          <div
            onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
            onDragLeave={() => setDrag(false)}
            onDrop={(e) => { e.preventDefault(); setDrag(false); accept(e.dataTransfer.files[0]); }}
            className={cn("rounded-3xl border-2 border-dashed p-8 text-center transition-colors", drag ? "border-violet bg-tint-violet" : "border-line-strong bg-white", error && "border-coral")}
          >
            <span className="mx-auto flex size-14 items-center justify-center rounded-2xl bg-tint-violet text-indigo"><UploadCloud className="size-7" /></span>
            <p className="mt-4 font-display text-base font-semibold">Drag and drop your ID here</p>
            <p className="mt-1 text-sm text-ink-2">JPG, PNG or PDF · up to 5 MB</p>
            <Button type="button" variant="secondary" className="mt-4" onClick={() => inputRef.current?.click()}>Choose a file</Button>
            <input ref={inputRef} type="file" accept=".jpg,.jpeg,.png,.pdf" className="sr-only" aria-label="Upload ID file" onChange={(e) => accept(e.target.files?.[0])} />
          </div>
        ) : (
          <div className="rounded-3xl border border-line bg-white p-4">
            <div className="flex items-start gap-4">
              <div className="flex size-24 shrink-0 items-center justify-center overflow-hidden rounded-xl bg-canvas">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                {preview ? <img src={preview} alt="Preview of your uploaded ID" className="size-full object-cover" /> : <FileImage className="size-8 text-ink-3" />}
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-semibold">{file.name}</p>
                <p className="text-xs text-ink-3">{(file.size / 1024).toFixed(0)} KB</p>
                <div className="mt-2">{scan === "scanning" ? <Badge tone="sky" dot>Reading fields…</Badge> : <SimulatedTag label="Simulated OCR" />}</div>
              </div>
              <Button variant="ghost" size="icon" onClick={clear} aria-label="Remove file"><Trash2 /></Button>
            </div>
            {scan === "scanning" && (
              <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-[#eef1fa]"><div className="skeleton h-full w-full !rounded-full" /></div>
            )}
            {scan === "done" && (
              <div className="mt-4">
                <p className="mb-2 flex items-center gap-1.5 text-xs font-semibold text-ink-2"><ScanLine className="size-3.5" /> Extracted fields (preview)</p>
                <dl className="grid gap-2 sm:grid-cols-2">
                  {fields.map(([k, v, c]) => (
                    <div key={k} className="rounded-xl bg-canvas px-3 py-2.5">
                      <dt className="text-[11px] text-ink-3">{k}</dt>
                      <dd className="flex items-center justify-between text-sm font-medium">{v}<span className={cn("text-[11px]", c < 95 ? "text-[#a86500]" : "text-[#008068]")}>{c}%</span></dd>
                    </div>
                  ))}
                </dl>
                <p className="mt-3 text-xs text-ink-2">These fields are synthetic samples, not extracted from your file. No OCR was performed.</p>
              </div>
            )}
          </div>
        )}
        {error && <p role="alert" className="text-sm text-[#d6294f]">{error}</p>}
        <p className="flex items-start gap-2 text-xs text-ink-2"><Lock className="mt-0.5 size-3.5 shrink-0" /> This preview stays in browser memory. No file is uploaded or retained in the demo review queue. Use a synthetic image for testing.</p>
        <Button variant="gradient" size="lg" className="w-full" disabled={!file || scan !== "done" || !invitee} onClick={() => { const result = submitDemoId(invitee?.id ?? ""); if (!result.ok) { toast.error(result.error); return; } toast.success("Demo preview added to the review queue"); router.push("/invite/employee/pending"); }}>Submit for review</Button>
      </div>
    </AuthShell>
  );
}

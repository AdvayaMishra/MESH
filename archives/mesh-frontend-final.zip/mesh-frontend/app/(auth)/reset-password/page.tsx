"use client";
import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { AuthShell } from "@/components/features/auth/auth-shell";
import { Button } from "@/components/ui/button";
import { Field } from "@/components/ui/input";
import { PasswordField, PasswordMeter, passwordScore } from "@/components/features/auth/password-field";

const schema = z.object({
  password: z.string().min(10, "Use at least 10 characters").refine((v) => passwordScore(v) >= 3, "Add a number, a symbol or mixed case"),
  confirm: z.string(),
}).refine((d) => d.password === d.confirm, { message: "Passwords don’t match", path: ["confirm"] });

export default function ResetPasswordPage() {
  const router = useRouter();
  const { register, handleSubmit, watch, formState: { errors, isSubmitting } } = useForm<z.infer<typeof schema>>({ resolver: zodResolver(schema) });
  return (
    <AuthShell title="Choose a new password" subtitle="You’ll use it the next time you log in." simulated footer={<Link href="/login" className="font-semibold text-indigo hover:underline">Back to log in</Link>}>
      <form noValidate className="space-y-4" onSubmit={handleSubmit(async () => { await new Promise((r) => setTimeout(r, 600)); toast.success("Password updated (simulated)"); router.push("/login"); })}>
        <Field label="New password" htmlFor="password" error={errors.password?.message}>
          <PasswordField id="password" autoComplete="new-password" aria-invalid={!!errors.password} {...register("password")} />
          <PasswordMeter value={watch("password") ?? ""} />
        </Field>
        <Field label="Confirm password" htmlFor="confirm" error={errors.confirm?.message}><PasswordField id="confirm" autoComplete="new-password" aria-invalid={!!errors.confirm} {...register("confirm")} /></Field>
        <Button type="submit" variant="gradient" size="lg" className="w-full" disabled={isSubmitting}>{isSubmitting ? "Updating…" : "Update password"}</Button>
      </form>
    </AuthShell>
  );
}

"use client";
import * as React from "react";
import Link from "next/link";
import { MailCheck } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { AuthShell } from "@/components/features/auth/auth-shell";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";

const schema = z.object({ email: z.string().email("Enter a valid email") });

export default function ForgotPasswordPage() {
  const [sent, setSent] = React.useState<string | null>(null);
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<z.infer<typeof schema>>({ resolver: zodResolver(schema) });
  return (
    <AuthShell title={sent ? "Check your inbox" : "Reset your password"} subtitle={sent ? `If an account exists for ${sent}, a reset link is on its way.` : "Enter your email and we’ll send a reset link."} simulated footer={<Link href="/login" className="font-semibold text-indigo hover:underline">Back to log in</Link>}>
      {sent ? (
        <div className="space-y-4 text-center">
          <span className="mx-auto flex size-16 items-center justify-center rounded-full bg-tint-mint text-[#008068]"><MailCheck className="size-8" /></span>
          <Button variant="gradient" size="lg" className="w-full" asChild><Link href="/reset-password">Open reset link (demo)</Link></Button>
        </div>
      ) : (
        <form noValidate className="space-y-4" onSubmit={handleSubmit(async (v) => { await new Promise((r) => setTimeout(r, 600)); setSent(v.email); })}>
          <Field label="Email" htmlFor="email" error={errors.email?.message}><Input id="email" type="email" autoComplete="email" aria-invalid={!!errors.email} {...register("email")} /></Field>
          <Button type="submit" variant="gradient" size="lg" className="w-full" disabled={isSubmitting}>{isSubmitting ? "Sending…" : "Send reset link"}</Button>
        </form>
      )}
    </AuthShell>
  );
}

"use client";
import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { AuthShell } from "@/components/features/auth/auth-shell";
import { ownerSteps } from "@/components/features/auth/stepper";
import { Button } from "@/components/ui/button";
import { Field, Input } from "@/components/ui/input";
import { PasswordField, PasswordMeter, passwordScore } from "@/components/features/auth/password-field";
import { CaptchaPlaceholder } from "@/components/features/auth/captcha";
import { useOnboarding } from "@/stores/onboarding-store";

const schema = z.object({
  company: z.string().min(2, "Enter your company name"),
  owner: z.string().min(2, "Enter your full name"),
  email: z.string().email("Enter a valid email address").refine((v) => !/@(gmail|yahoo|outlook|hotmail)\./i.test(v), "Use your official company email, not a personal one"),
  password: z.string().min(10, "Use at least 10 characters").refine((v) => passwordScore(v) >= 3, "Add a number, a symbol or mixed case"),
  captcha: z.boolean().refine((v) => v, "Please confirm you are not a robot"),
});
type Values = z.infer<typeof schema>;

export default function RegisterPage() {
  const router = useRouter();
  const setOnboarding = useOnboarding((s) => s.set);
  const { register, handleSubmit, control, watch, formState: { errors, isSubmitting } } = useForm<Values>({
    resolver: zodResolver(schema),
    defaultValues: { company: "", owner: "", email: "", password: "", captcha: false },
  });
  const pw = watch("password");

  return (
    <AuthShell
      title="Create your organization"
      subtitle="Start with the owner account. You’ll verify your email and domain next."
      steps={ownerSteps}
      current={0}
      footer={<>Already have an account? <Link href="/login" className="font-semibold text-indigo hover:underline">Log in</Link></>}
    >
      <form
        noValidate
        className="space-y-4"
        onSubmit={handleSubmit(async (v) => {
          await new Promise((r) => setTimeout(r, 600));
          setOnboarding({ companyName: v.company, ownerName: v.owner, email: v.email });
          router.push("/register/verify");
        })}
      >
        <Field label="Company name" htmlFor="company" error={errors.company?.message}>
          <Input id="company" autoComplete="organization" placeholder="Lumen Robotics" aria-invalid={!!errors.company} {...register("company")} />
        </Field>
        <Field label="Your name" htmlFor="owner" error={errors.owner?.message}>
          <Input id="owner" autoComplete="name" placeholder="Alex Morgan" aria-invalid={!!errors.owner} {...register("owner")} />
        </Field>
        <Field label="Official email" htmlFor="email" error={errors.email?.message} hint="We’ll send a 6-digit code to confirm it.">
          <Input id="email" type="email" autoComplete="email" placeholder="alex@lumenrobotics.io" aria-invalid={!!errors.email} {...register("email")} />
        </Field>
        <Field label="Password" htmlFor="password" error={errors.password?.message}>
          <PasswordField id="password" autoComplete="new-password" aria-invalid={!!errors.password} {...register("password")} />
          <PasswordMeter value={pw} />
        </Field>
        <Controller control={control} name="captcha" render={({ field }) => <CaptchaPlaceholder checked={field.value} onChange={field.onChange} error={errors.captcha?.message} />} />
        <Button type="submit" variant="gradient" size="lg" className="w-full" disabled={isSubmitting}>
          {isSubmitting ? "Creating account…" : "Continue"}
        </Button>
      </form>
    </AuthShell>
  );
}

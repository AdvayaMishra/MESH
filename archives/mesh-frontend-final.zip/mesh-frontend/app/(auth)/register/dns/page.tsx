"use client";
import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Loader2 } from "lucide-react";
import { AuthShell } from "@/components/features/auth/auth-shell";
import { ownerSteps } from "@/components/features/auth/stepper";
import { Button } from "@/components/ui/button";
import { CopyButton } from "@/components/ui/copy-button";
import { Badge, SimulatedTag } from "@/components/ui/badge";
import { api } from "@/lib/api";
import { makeVerificationCode, useOnboarding } from "@/stores/onboarding-store";

export default function DnsVerificationPage() {
  const router = useRouter();
  const { website, verificationCode, set } = useOnboarding();
  const host = website || "yourcompany.com";
  const code = verificationCode || makeVerificationCode(host);
  const [state, setState] = React.useState<"idle" | "checking" | "simulated-pass">("idle");

  const rows = [["Type", "TXT"], ["Name / Host", "@"], ["Value", code], ["TTL", "3600 (or Auto)"]];

  return (
    <AuthShell wide title="Add a DNS TXT record" subtitle={`Create this record at the DNS provider that manages ${host}.`} steps={ownerSteps} current={3} simulated>
      <div className="space-y-5">
        <div className="overflow-hidden rounded-2xl border border-line">
          {rows.map(([k, v]) => (
            <div key={k} className="flex items-center justify-between gap-3 border-b border-line px-4 py-3 last:border-0">
              <span className="w-28 shrink-0 text-xs font-medium text-ink-3">{k}</span>
              <code className="min-w-0 flex-1 break-all font-mono text-sm text-ink">{v}</code>
              {k === "Value" && <CopyButton value={code} />}
            </div>
          ))}
        </div>
        <ul className="list-disc space-y-1.5 pl-5 text-sm text-ink-2">
          <li>DNS changes can take up to 48 hours to propagate, though it is often minutes.</li>
          <li>Keep the record in place. We may re-check it periodically.</li>
          <li>Cloudflare, GoDaddy, Route 53 and Namecheap all accept this format.</li>
        </ul>
        <div className="rounded-2xl border border-line p-4" aria-live="polite">
          <div className="flex items-center justify-between">
            <p className="text-sm font-semibold">Record status</p>
            {state === "idle" && <Badge tone="neutral" dot>Not checked</Badge>}
            {state === "checking" && <Badge tone="sky" dot>Looking up TXT…</Badge>}
            {state === "simulated-pass" && <SimulatedTag label="Simulated check passed" />}
          </div>
          {state === "simulated-pass" && <p className="mt-2 text-[13px] text-ink-2">Demo result only. No DNS lookup was made, so this domain is not actually verified.</p>}
        </div>
        <div className="flex flex-col gap-3 sm:flex-row">
          <Button
            variant="gradient" size="lg" className="flex-1" disabled={state === "checking"}
            onClick={async () => {
              if (state === "simulated-pass") return router.push("/register/pending");
              setState("checking");
              await api.verifyWebsite("dns", code);
              setState("simulated-pass");
              set({ domainCheck: "simulated-pass", verificationCode: code });
            }}
          >
            {state === "checking" ? <><Loader2 className="animate-spin" /> Checking…</> : state === "simulated-pass" ? "Continue" : "Check DNS record"}
          </Button>
          <Button variant="secondary" size="lg" asChild><Link href="/register/website">Use a file instead</Link></Button>
        </div>
      </div>
    </AuthShell>
  );
}

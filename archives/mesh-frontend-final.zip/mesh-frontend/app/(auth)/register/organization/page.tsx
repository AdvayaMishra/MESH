"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { AuthShell } from "@/components/features/auth/auth-shell";
import { ownerSteps } from "@/components/features/auth/stepper";
import { Button } from "@/components/ui/button";
import { Field, Input, Select } from "@/components/ui/input";
import { makeVerificationCode, useOnboarding } from "@/stores/onboarding-store";

const schema = z.object({
  company: z.string().min(2, "Enter the legal or trading name"),
  website: z.string().regex(/^(https?:\/\/)?([a-z0-9-]+\.)+[a-z]{2,}(\/.*)?$/i, "Enter a valid website, like lumenrobotics.io"),
  industry: z.string().min(1, "Choose an industry"),
  size: z.string().min(1, "Choose a team size"),
});
type Values = z.infer<typeof schema>;

export default function OrganizationPage() {
  const router = useRouter();
  const { companyName, set } = useOnboarding();
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<Values>({
    resolver: zodResolver(schema),
    defaultValues: { company: companyName, website: "", industry: "", size: "" },
  });
  return (
    <AuthShell title="Tell us about your organization" subtitle="We use this to set up your workspace and to verify that you control the website." steps={ownerSteps} current={2}>
      <form
        noValidate
        className="space-y-4"
        onSubmit={handleSubmit(async (v) => {
          await new Promise((r) => setTimeout(r, 500));
          const host = v.website.replace(/^https?:\/\//, "").replace(/\/.*$/, "");
          set({ companyName: v.company, website: host, industry: v.industry, size: v.size, verificationCode: makeVerificationCode(host) });
          router.push("/register/website");
        })}
      >
        <Field label="Company name" htmlFor="company" error={errors.company?.message}><Input id="company" aria-invalid={!!errors.company} {...register("company")} /></Field>
        <Field label="Company website" htmlFor="website" error={errors.website?.message} hint="The official site you’ll verify in the next step.">
          <Input id="website" placeholder="lumenrobotics.io" aria-invalid={!!errors.website} {...register("website")} />
        </Field>
        <div className="grid gap-4 sm:grid-cols-2">
          <Field label="Industry" htmlFor="industry" error={errors.industry?.message}>
            <Select id="industry" defaultValue="" aria-invalid={!!errors.industry} {...register("industry")}>
              <option value="" disabled>Select…</option>
              {["Software", "Robotics & hardware", "Financial services", "Healthcare", "Retail", "Education", "Other"].map((o) => <option key={o}>{o}</option>)}
            </Select>
          </Field>
          <Field label="Team size" htmlFor="size" error={errors.size?.message}>
            <Select id="size" defaultValue="" aria-invalid={!!errors.size} {...register("size")}>
              <option value="" disabled>Select…</option>
              {["1–10", "11–50", "51–200", "201–1,000", "1,000+"].map((o) => <option key={o}>{o}</option>)}
            </Select>
          </Field>
        </div>
        <Button type="submit" variant="gradient" size="lg" className="w-full" disabled={isSubmitting}>{isSubmitting ? "Saving…" : "Continue to verification"}</Button>
      </form>
    </AuthShell>
  );
}

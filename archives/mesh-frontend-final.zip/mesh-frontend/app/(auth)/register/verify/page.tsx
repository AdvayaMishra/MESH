"use client";
import * as React from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { AuthShell } from "@/components/features/auth/auth-shell";
import { ownerSteps } from "@/components/features/auth/stepper";
import { OtpInput } from "@/components/features/auth/otp-input";
import { Button } from "@/components/ui/button";
import { useOnboarding } from "@/stores/onboarding-store";

export default function VerifyEmailPage() {
  const router = useRouter();
  const { email, set } = useOnboarding();
  const [code, setCode] = React.useState("");
  const [error, setError] = React.useState("");
  const [busy, setBusy] = React.useState(false);
  const [cooldown, setCooldown] = React.useState(30);

  React.useEffect(() => {
    if (cooldown <= 0) return;
    const t = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [cooldown]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (code.length < 6) return setError("Enter all 6 digits");
    setBusy(true);
    await new Promise((r) => setTimeout(r, 700));
    setBusy(false);
    if (code !== "482913") return setError("That code doesn’t match. Check the digits and try again.");
    set({ emailVerified: true });
    router.push("/register/organization");
  }

  return (
    <AuthShell
      title="Check your email"
      subtitle={`We sent a 6-digit code to ${email || "your email"}. It expires in 10 minutes.`}
      steps={ownerSteps}
      current={1}
      simulated
    >
      <form onSubmit={submit} className="space-y-5">
        <div>
          <OtpInput value={code} onChange={(v) => { setCode(v); setError(""); }} invalid={!!error} />
          {error && <p role="alert" className="mt-2 text-sm text-[#d6294f]">{error}</p>}
        </div>
        <p className="rounded-xl bg-tint-violet px-3.5 py-2.5 text-[13px] text-indigo">Prototype only: enter <span className="font-mono font-semibold">482913</span> to continue.</p>
        <Button type="submit" variant="gradient" size="lg" className="w-full" disabled={busy}>{busy ? "Verifying…" : "Verify email"}</Button>
        <div className="text-center text-sm text-ink-2">
          Didn’t get it?{" "}
          <button type="button" disabled={cooldown > 0} onClick={() => { setCooldown(30); toast.success("A new code was sent (simulated)"); }} className="font-semibold text-indigo hover:underline disabled:text-ink-3 disabled:no-underline">
            {cooldown > 0 ? `Resend in ${cooldown}s` : "Resend code"}
          </button>
        </div>
      </form>
    </AuthShell>
  );
}

"use client";
import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { CheckCircle2, Clock, Rocket } from "lucide-react";
import { AuthShell } from "@/components/features/auth/auth-shell";
import { ownerSteps } from "@/components/features/auth/stepper";
import { Button } from "@/components/ui/button";
import { SimulatedTag } from "@/components/ui/badge";
import { useOnboarding } from "@/stores/onboarding-store";
import { cn } from "@/lib/utils/cn";
import { useUI } from "@/stores/ui-store";

export default function PendingPage() {
  const router = useRouter();
  const { companyName, website } = useOnboarding();
  const [phase, setPhase] = React.useState<"pending" | "done">("pending");
  React.useEffect(() => {
    const t = setTimeout(() => setPhase("done"), 2800);
    return () => clearTimeout(t);
  }, []);

  const rows = [
    { l: "Account details previewed", s: "done" as const },
    { l: "Email confirmation previewed", s: "done" as const },
    { l: "Organization details captured locally", s: "done" as const },
    { l: `Domain ownership of ${website || "your site"}`, s: phase === "done" ? ("sim" as const) : ("wait" as const) },
  ];

  return (
    <AuthShell title={phase === "pending" ? "Previewing organization review" : "Onboarding preview complete"} subtitle={phase === "pending" ? "This usually takes a moment." : `${companyName || "Your organization"} details were captured for this preview. Open a seeded example workspace to explore MESH.`} steps={ownerSteps} current={4} simulated>
      <ul className="space-y-3" aria-live="polite">
        {rows.map((r) => (
          <li key={r.l} className="flex items-center gap-3 rounded-xl border border-line bg-white px-4 py-3">
            {r.s === "wait" ? <Clock className="size-5 animate-pulse text-sky" /> : <CheckCircle2 className={cn("size-5", r.s === "sim" ? "text-amber" : "text-mint")} />}
            <span className="flex-1 text-sm font-medium text-ink">{r.l}</span>
            {r.s === "sim" && <SimulatedTag label="Simulated" />}
          </li>
        ))}
      </ul>
      {phase === "done" && (
        <div className="mt-6 space-y-3">
          <p className="rounded-xl bg-tint-amber px-4 py-3 text-[13px] text-[#8a5200]">Domain status is <strong>simulated</strong>. In production this would show Verified only after a real DNS or file check succeeds.</p>
          <Button variant="gradient" size="lg" className="w-full" onClick={() => { useUI.getState().setRole("owner"); router.push("/owner"); }}><Rocket /> Open example dashboard</Button>
          <Button variant="ghost" className="w-full" asChild><Link href="/">Back to home</Link></Button>
        </div>
      )}
    </AuthShell>
  );
}

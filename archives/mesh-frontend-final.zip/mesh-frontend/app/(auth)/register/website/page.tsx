"use client";
import * as React from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { CheckCircle2, Globe, Loader2, FileText } from "lucide-react";
import { AuthShell } from "@/components/features/auth/auth-shell";
import { ownerSteps } from "@/components/features/auth/stepper";
import { Button } from "@/components/ui/button";
import { CopyButton } from "@/components/ui/copy-button";
import { Badge, SimulatedTag } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { api } from "@/lib/api";
import { makeVerificationCode, useOnboarding } from "@/stores/onboarding-store";

export default function WebsiteVerificationPage() {
  const router = useRouter();
  const { website, verificationCode, set } = useOnboarding();
  const host = website || "yourcompany.com";
  const code = verificationCode || makeVerificationCode(host);
  const [method, setMethod] = React.useState<"file" | "meta">("file");
  const [state, setState] = React.useState<"idle" | "checking" | "simulated-pass">("idle");

  async function check() {
    setState("checking");
    await api.verifyWebsite("file", code);
    setState("simulated-pass");
    set({ domainCheck: "simulated-pass", verificationCode: code });
  }

  return (
    <AuthShell
      wide
      title="Verify your website"
      subtitle={`Prove that you control ${host} by publishing the code below.`}
      steps={ownerSteps}
      current={3}
      simulated
    >
      <div className="space-y-5">
        <div className="rounded-2xl border border-violet/25 bg-tint-violet p-4">
          <p className="text-xs font-medium text-indigo">Your verification code</p>
          <div className="mt-2 flex flex-wrap items-center gap-3">
            <code className="min-w-0 flex-1 break-all rounded-xl bg-white px-3.5 py-3 font-mono text-sm font-semibold text-ink">{code}</code>
            <CopyButton value={code} label="Copy code" />
          </div>
        </div>

        <Tabs value={method} onValueChange={(v) => setMethod(v as "file" | "meta")}>
          <TabsList>
            <TabsTrigger value="file"><FileText className="mr-1.5 inline size-3.5" />Upload a file</TabsTrigger>
            <TabsTrigger value="meta"><Globe className="mr-1.5 inline size-3.5" />Add a meta tag</TabsTrigger>
          </TabsList>
          <TabsContent value="file">
            <ol className="space-y-3 text-sm text-ink-2">
              <li>1. Create a text file named <code className="rounded bg-canvas px-1.5 py-0.5 font-mono text-xs text-ink">mesh-verification.txt</code>.</li>
              <li>2. Paste the code above as the only content of the file.</li>
              <li>3. Upload it so it’s reachable at:
                <div className="mt-2 flex flex-wrap items-center gap-2">
                  <code className="break-all rounded-lg bg-canvas px-2.5 py-1.5 font-mono text-xs text-ink">https://{host}/.well-known/mesh-verification.txt</code>
                  <CopyButton value={`https://${host}/.well-known/mesh-verification.txt`} label="Copy URL" />
                </div>
              </li>
            </ol>
          </TabsContent>
          <TabsContent value="meta">
            <p className="text-sm text-ink-2">Add this tag inside the <code className="rounded bg-canvas px-1.5 py-0.5 font-mono text-xs">&lt;head&gt;</code> of your home page:</p>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <code className="break-all rounded-lg bg-canvas px-2.5 py-2 font-mono text-xs text-ink">{`<meta name="mesh-verification" content="${code}" />`}</code>
              <CopyButton value={`<meta name="mesh-verification" content="${code}" />`} label="Copy tag" />
            </div>
          </TabsContent>
        </Tabs>

        <div className="rounded-2xl border border-line p-4" aria-live="polite">
          <div className="flex items-center justify-between gap-3">
            <p className="text-sm font-semibold text-ink">Verification status</p>
            {state === "idle" && <Badge tone="neutral" dot>Not checked</Badge>}
            {state === "checking" && <Badge tone="sky" dot>Checking…</Badge>}
            {state === "simulated-pass" && <SimulatedTag label="Simulated check passed" />}
          </div>
          {state === "simulated-pass" && (
            <p className="mt-2 flex items-start gap-2 text-[13px] text-ink-2"><CheckCircle2 className="mt-0.5 size-4 shrink-0 text-amber" />This is a demo result. Your site was not contacted, so {host} is <strong className="text-ink">not</strong> actually verified.</p>
          )}
        </div>

        <div className="flex flex-col gap-3 sm:flex-row">
          <Button variant="gradient" size="lg" className="flex-1" onClick={state === "simulated-pass" ? () => router.push("/register/pending") : check} disabled={state === "checking"}>
            {state === "checking" ? <><Loader2 className="animate-spin" /> Checking…</> : state === "simulated-pass" ? "Continue" : "Check verification"}
          </Button>
          <Button variant="secondary" size="lg" asChild><Link href="/register/dns">Use a DNS record instead</Link></Button>
        </div>
      </div>
    </AuthShell>
  );
}

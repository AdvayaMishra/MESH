import { redirect } from "next/navigation";

/** `/workspace` has no content of its own; the breadcrumb links here, so send people to their inbox. */
export default function WorkspaceIndex() {
  redirect("/workspace/notifications");
}

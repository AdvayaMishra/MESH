import { Sidebar } from "@/components/layout/sidebar";
import { Topbar } from "@/components/layout/topbar";
import { CommandPalette } from "@/components/layout/command-palette";
import { TooltipProvider } from "@/components/ui/tooltip";
import { RouteGuard, UIHydrator } from "@/components/layout/route-guard";

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  return (
    <TooltipProvider>
      <UIHydrator />
      <div className="flex min-h-dvh">
        <Sidebar />
        <div className="flex min-w-0 flex-1 flex-col">
          <Topbar />
          <main id="main" className="mx-auto w-full max-w-[1480px] flex-1 px-4 py-6 sm:px-6 lg:px-8">
            <RouteGuard>{children}</RouteGuard>
          </main>
        </div>
      </div>
      <CommandPalette />
    </TooltipProvider>
  );
}

# MESH frontend

Enterprise demonstration frontend for OWNER, PEOPLE, DEVTRACK and VADER, completed from the supplied `mesh-frontend-continued-3.zip` while preserving its design system.

## Run

Requires Node.js 24+, npm and Google Chrome for the configured browser tests.

```powershell
npm ci
npm run build
npm start -- --hostname 127.0.0.1 --port 3001
```

Open `http://127.0.0.1:3001/login`. Use the account menu for the five demo roles and the organization menu for Lumen/Northwind. Business edits survive client-side navigation, role changes and tenant switching within the session. Full reload resets in-memory business data; only role/tenant selection uses browser-tab session storage. No credential or uploaded ID is persisted by this demo.

## Verify

```powershell
npm test
npm run test:logic
npm run audit:source
npm run typecheck
npm run lint
npm run build
npm run test:e2e
# Or run all seven gates and record their actual exit codes:
npm run verify:release
```

The release runner uses actual installed React/Zustand, checks unchanged source fingerprints and starts a bounded loopback browser-test server. Historical shim-based scripts are retained for reference and are not release evidence.

## Capabilities and integration

Organization/employee administration, department budgets, project decisions/allocation, task CRUD and sprints, PR review/merge simulation, scan/finding workflows, ID review/activation, independent lifecycle and payroll review, leave/promotions/private complaints, incident investigation and response reversal, cloud remediation, grounded free-text assistants, role-scoped search/notifications/audit and CSV/XLSX/print-PDF exports and profile/photo/preferences are implemented as demo workflows. Reports support actual CSV and OOXML Excel downloads, record-date filters where timestamps are supplied, and a local printable view with browser Save as PDF.

Authentication, domain checks, scans, cloud/provider actions, payments, email and hosted AI require the separate backend. No real repository, cloud access or payment is changed by this UI. Frontend role controls are a demo UX, not a security boundary. The earlier backend-connected preview remains separate and has not been overwritten.

- [Completion matrix](FRONTEND_COMPLETION_MATRIX.md)
- [Implementation status](FRONTEND_IMPLEMENTATION_STATUS.md)
- [Test report](FRONTEND_TEST_REPORT.md)
- [Backend integration guide](BACKEND_INTEGRATION_GUIDE.md)

Prior supplied reports are preserved under `docs/history/`. Generated dependencies, build caches, credentials and browser traces are excluded from the ZIP.
